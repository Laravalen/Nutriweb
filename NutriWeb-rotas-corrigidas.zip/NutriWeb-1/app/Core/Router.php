<?php
namespace App\Core;

class Router
{
    private array $routes = [];

    public function get(string $path, array $handler): void
    {
        $this->routes['GET'][$path] = $handler;
    }

    public function post(string $path, array $handler): void
    {
        $this->routes['POST'][$path] = $handler;
    }

    public function dispatch(string $method, string $uri): void
    {
        $uri = '/' . trim(parse_url($uri, PHP_URL_PATH) ?: '/', '/');
        if ($uri === '//') {
            $uri = '/';
        }

        foreach ($this->routes[strtoupper($method)] ?? [] as $route => $handler) {
            $quoted = preg_quote($route, '#');
            $pattern = preg_replace('/\\\\\{[a-zA-Z0-9_]+\\\\\}/', '([0-9]+)', $quoted);
            if (preg_match('#^' . $pattern . '/?$#', $uri, $matches)) {
                array_shift($matches);
                [$controllerClass, $action] = $handler;
                $controller = new $controllerClass();
                call_user_func_array([$controller, $action], array_map('intval', $matches));
                return;
            }
        }

        http_response_code(404);
        echo '<h1>404 - Página não encontrada</h1>';
        echo '<p>Verifique o endereço ou volte para a página inicial.</p>';
        echo '<a href="' . htmlspecialchars(base_url('/'), ENT_QUOTES, 'UTF-8') . '">Voltar ao início</a>';
    }
}
