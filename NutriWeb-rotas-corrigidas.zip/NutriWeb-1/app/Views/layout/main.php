<?php $user = current_user(); $flash = get_flash(); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NutriWeb — Alta Gastronomia e Kits Mise en Place</title>
    <link rel="stylesheet" href="<?= e(base_url('/assets/css/app.css')) ?>">
</head>
<body>
    <header class="navbar">
        <div class="container">
            <a href="<?= e(base_url('/')) ?>" class="brand">
                <img src="<?= e(base_url('/assets/img/nutriweb-logo.png')) ?>" alt="NutriWeb" onerror="this.style.display='none'">
                <span>NutriWeb</span>
            </a>
            <nav class="nav-links">
                <a href="<?= e(base_url('/')) ?>">Receitas</a>
                <a href="<?= e(base_url('/kits')) ?>">Kits Mise en Place</a>
                <a href="<?= e(base_url('/quero-ser-criador')) ?>">Para Chefs e Restaurantes</a>
                <?php if ($user && $user['role'] === 'creator'): ?>
                    <a href="<?= e(base_url('/nova-receita')) ?>" class="badge badge-exclusive">+ Publicar Receita</a>
                <?php endif; ?>
                <?php if ($user && $user['role'] === 'admin'): ?>
                    <a href="<?= e(base_url('/admin')) ?>" class="badge badge-sanitary">Painel Curadoria</a>
                <?php endif; ?>
            </nav>
            <div class="nav-actions">
                <?php if ($user): ?>
                    <span class="user-pill"><?= e($user['name']) ?> <?= $user['is_subscriber'] ? '★ Clube' : '' ?></span>
                    <a href="<?= e(base_url('/logout')) ?>" class="btn btn-outline">Sair</a>
                <?php else: ?>
                    <a href="<?= e(base_url('/login')) ?>" class="btn btn-outline">Entrar</a>
                    <a href="<?= e(base_url('/register')) ?>" class="btn btn-primary">Criar Conta</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <main class="container">
        <?php if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>
        <?= $content ?>
    </main>

    <footer>
        <div class="container footer-grid">
            <div>
                <h3>NutriWeb</h3>
                <p>Receitas exclusivas com curadoria profissional e insumos frescos porcionados na medida certa.</p>
            </div>
            <div>
                <strong>Conformidade & Qualidade</strong>
                <p>Curadoria com validação de CNPJ/Alvará e entrega refrigerada restrita por raio local.</p>
            </div>
        </div>
    </footer>
    <script src="<?= e(base_url('/assets/js/app.js')) ?>"></script>
</body>
</html>