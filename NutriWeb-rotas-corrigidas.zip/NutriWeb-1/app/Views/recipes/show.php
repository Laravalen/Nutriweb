<?php $user = current_user(); ?>
<article class="recipe-detail">
    <div class="recipe-header">
        <span class="badge badge-exclusive"><?= e($recipe['category']) ?></span>
        <span class="badge badge-sanitary"><?= e($recipe['dietary_restriction']) ?></span>
        <h1><?= e($recipe['title']) ?></h1>
        <p class="muted">
            Por <strong><?= e($recipe['chef_name']) ?></strong>
            · <?= e($recipe['business_name'] ?? 'Chef Oficial') ?>
            · ⏱ <?= (int)$recipe['prep_time_minutes'] ?> min
        </p>
        <p><?= e($recipe['description']) ?></p>
    </div>

    <?php if ($hasAccess): ?>
        <section class="protected-media">
            <div class="watermark-overlay">
                LICENCIADO PARA: <?= e(strtoupper($user['name'] ?? 'ASSINANTE')) ?>
                (<?= e($user['email'] ?? '') ?>)
                · TOKEN <?= e($recipe['video_stream_token']) ?>
            </div>
            <h3>🎬 Videoaula Técnica Exclusiva (Streaming Protegido)</h3>
            <p>Reproduzindo aula passo a passo em 4K com marca d'água dinâmica anti-pirataria.</p>
            <div class="video-placeholder">
                ▶ Aula em execução — Segredos de emulsão e finalização do Chef <?= e($recipe['chef_name']) ?>
            </div>
        </section>

        <div class="recipe-columns">
            <section class="card">
                <h3>Ingredientes Porcionados</h3>
                <pre class="recipe-text"><?= e($recipe['ingredients']) ?></pre>
                <?php if (!empty($recipe['zero_waste_tip'])): ?>
                    <div class="alert alert-success">
                        <strong>🌱 Aproveitamento Integral (Zero Desperdício):</strong>
                        <?= e($recipe['zero_waste_tip']) ?>
                    </div>
                <?php endif; ?>
            </section>

            <section class="card protected-media" style="background: var(--bg-card); color: var(--espresso);">
                <div class="watermark-overlay" style="color: rgba(142, 40, 11, 0.09);">
                    CÓPIA RASTREÁVEL · <?= e($user['email'] ?? '') ?>
                </div>
                <h3>Modo de Preparo Detalhado</h3>
                <pre class="recipe-text"><?= e($recipe['steps']) ?></pre>
            </section>
        </div>
    <?php else: ?>
        <section class="paywall-box">
            <h3>Conteúdo Exclusivo Protegido</h3>
            <p>Desbloqueie a videoaula completa e a ficha técnica com marca d'água pessoal.</p>
            <div class="hero-actions">
                <?php if ($user): ?>
                    <form method="POST" action="<?= e(base_url('/receita/' . (int)$recipe['id'] . '/desbloquear')) ?>">
                        <button type="submit" class="btn btn-primary">
                            Comprar Receita Avulsa (R$ <?= number_format((float)$recipe['price'], 2, ',', '.') ?>)
                        </button>
                    </form>
                <?php else: ?>
                    <a href="<?= e(base_url('/login')) ?>" class="btn btn-primary">Entre para desbloquear</a>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!empty($linkedKit)): ?>
        <section class="card">
            <h3>Kit Mise en Place relacionado</h3>
            <p><?= e($linkedKit['title']) ?> · <?= (int)$linkedKit['servings'] ?> porções</p>
            <p><strong>R$ <?= number_format((float)$linkedKit['price'], 2, ',', '.') ?></strong></p>
            <a href="<?= e(base_url('/kits')) ?>" class="btn btn-outline">Ver kits disponíveis</a>
        </section>
    <?php endif; ?>

    <section class="card community-section">
        <h2>Comunidade NutriWeb</h2>
        <?php if ($user): ?>
            <form method="POST" action="<?= e(base_url('/receita/' . (int)$recipe['id'] . '/comunidade')) ?>" class="form-stack">
                <label>Tipo de publicação
                    <select name="type">
                        <option value="result">Compartilhar resultado</option>
                        <option value="question">Fazer uma pergunta</option>
                    </select>
                </label>
                <label>Sua mensagem
                    <textarea name="content" rows="3" required></textarea>
                </label>
                <label>Avaliação
                    <select name="rating">
                        <?php for ($rating = 5; $rating >= 1; $rating--): ?>
                            <option value="<?= $rating ?>"><?= $rating ?> estrela(s)</option>
                        <?php endfor; ?>
                    </select>
                </label>
                <button type="submit" class="btn btn-primary">Publicar</button>
            </form>
        <?php else: ?>
            <p><a href="<?= e(base_url('/login')) ?>">Entre na sua conta</a> para participar da comunidade.</p>
        <?php endif; ?>

        <?php if (!empty($posts)): ?>
            <div class="community-posts">
                <?php foreach ($posts as $post): ?>
                    <article class="community-post">
                        <p><strong><?= e($post['author_name']) ?></strong>
                            · <?= $post['type'] === 'question' ? 'Pergunta' : 'Resultado' ?>
                            · <?= (int)$post['rating'] ?>/5</p>
                        <p><?= nl2br(e($post['content'])) ?></p>
                        <?php if (!empty($post['chef_reply'])): ?>
                            <p class="muted"><strong>Resposta do chef:</strong> <?= nl2br(e($post['chef_reply'])) ?></p>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="muted">Ainda não há publicações sobre esta receita.</p>
        <?php endif; ?>
    </section>
</article>
